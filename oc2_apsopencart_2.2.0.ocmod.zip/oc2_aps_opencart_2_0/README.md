## Changelog

`v2.2.0`
- Single Card Form Config for Installments and Cards

`v2.1.0`
- Install Apple pay in cart page and product page

`v2.0.0`
- Release Amazon payment service opencart extension
