<?php
$_['heading_title'] = '<span id="amazon_ps_valu">Amazon Payment Services </span><script>$("#extension #amazon_ps_valu").closest("tr").remove();</script>';