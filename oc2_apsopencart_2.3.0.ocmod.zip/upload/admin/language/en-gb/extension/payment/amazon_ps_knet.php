<?php
$_['heading_title'] = '<span id="amazon_ps_knet">Amazon Payment Services </span><script>$("#extension #amazon_ps_knet").closest("tr").remove();</script>'; 